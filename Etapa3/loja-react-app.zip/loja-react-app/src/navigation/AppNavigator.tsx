import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { RootStackParamList, TabParamList } from './types';
import FontAwesome from '@expo/vector-icons/FontAwesome';

// Telas do app - area não logada
import HomeScreen from '../screens/HomeScreen';
import RegisterScreen from '../screens/RegisterScreen';
import LoginScreen from '../screens/LoginScreen';
// importar depois que implementar: DetailsScreen, SettingsScreen
import CatalogScreen from '../screens/catalog/CatalogScreen';
import CartScreen from '../screens/cart/CartScreen';

const AppStack = createNativeStackNavigator<RootStackParamList>();
const Tab = createBottomTabNavigator<TabParamList>();

function TabNavigator() {
    return (
        <Tab.Navigator
            screenOptions={({ route, navigation}) => ({
                tabBarIcon: ({ color, focused, size }) => {
                    let iconName;
                if (route.name === 'Catalog') {
                    iconName = focused ? 'tags' : 'tags';
                }
                if (route.name === 'Cart') {
                    iconName = focused ? 'shopping-cart' : 'shopping-cart';
                }
                return <FontAwesome name={iconName} size={size} color={color} />;
                },
                tabBarActiveTintColor: 'red',
                tabBarInactiveTintColor: 'gray',
                headerShown: false,
            })}>
            <Tab.Screen 
                name="Catalog" 
                component={CatalogScreen}
                options={{ title: 'Menu' }} 
            />
            <Tab.Screen
                name="Cart" 
                component={CartScreen} 
                options={{ title: 'Seu Carrinho' }}
            />
            <Tab.Screen name="Settings" component={HomeScreen} />
            <Tab.Screen name="Register" component={RegisterScreen} />
        </Tab.Navigator>
    );
}

function StackNavigator() {
    return (
        <AppStack.Navigator>
            <AppStack.Screen
                name="Tabs"
                component={TabNavigator}
                options={{ headerShown: false }}
            />

            <AppStack.Screen
                name="Details"
                component={HomeScreen}
                options={{ title: 'Details' }}
            />
            <AppStack.Screen
                name="Login"
                component={LoginScreen}
                options={{ title: 'Acessar' }}/>
        </AppStack.Navigator>
    );
}

export default function AppNavigator() {
    return (
            <StackNavigator />
    );
}
